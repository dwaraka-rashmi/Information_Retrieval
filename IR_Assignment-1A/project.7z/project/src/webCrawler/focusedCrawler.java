package webCrawler;

import java.io.*;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class focusedCrawler{

	static int MAX_PAGES_TO_SEARCH = 1000;
	static String urlPrefix = "https://en.wikipedia.org/wiki/";

	static Set<String> pagesVisited = new HashSet<String>();
	static Set<String> top5PagesVisited = new HashSet<String>();
	static List<String> frontierUrlList = new LinkedList<String>();
	static Set<String> frontierUrlLookupSet = new HashSet<String>();

	static int fileCount = 1;

	public static Document fetchWebPage(String url){
		Document doc = null;
		try {
			doc = Jsoup.connect(url).header("Accept-Encoding", "gzip, deflate").maxBodySize(0).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return doc;
	}

	public static String nextUrl(){
		String nextUrl;
		do{
			nextUrl = frontierUrlList.remove(0); 
		} while(pagesVisited.contains(nextUrl));
		return nextUrl;
	}

	public static void clearDataStr(){
		pagesVisited.clear();
		top5PagesVisited.clear();
		frontierUrlList.clear();
		frontierUrlLookupSet.clear();
		fileCount = 1;
	}

	public static Boolean checkForKeyword(String url, String keyword) {
		if((fetchWebPage(url).html().contains(keyword)))
			return true;
		else return false;	
	}

	public static void doc_parse(String url, String keyword) throws IOException {

		Document doc = null;
		String frontierUrl; 
		doc = fetchWebPage(url);
		Elements links = doc.select("a[href]");

		for (Element link : links) {
			if(((link.attr("abs:href").startsWith(urlPrefix)))) {
				frontierUrl = (link.attr("abs:href").replace(urlPrefix," "));
				if(!(frontierUrl.contains(":"))) {  						
					frontierUrl = (frontierUrl.split("#"))[0];						
					frontierUrl = urlPrefix +frontierUrl.trim();				
					if (frontierUrlLookupSet.add(frontierUrl)) {
						if(!pagesVisited.contains(frontierUrl)) {
							if(frontierUrl.contains(keyword) || link.text().contains(keyword))
								frontierUrlList.add(frontierUrl);
							else if((checkForKeyword(frontierUrl,keyword))) {
									frontierUrlList.add(frontierUrl);
									pagesVisited.add(frontierUrl);
									if(top5PagesVisited.size()<=5)
										top5PagesVisited.add(frontierUrl);
									if(pagesVisited.size()>=MAX_PAGES_TO_SEARCH)
										break;
							}
						}
					}
				}
			}
		}

	}

	public static void bfs(String url, String keyword) throws IOException, InterruptedException {
		int depth = 1;
		System.out.print("\n-----------BFS procedure Focused Crawling----------\n");

		pagesVisited.add(url);
		top5PagesVisited.add(url);
		doc_parse(url,keyword);

		System.out.print("\n-----------depth = "+depth+"----------Total Pages Visited = "+pagesVisited.size()+"--------\n");
		depth++;
		int depthSize = frontierUrlList.size();

		while( (depth <=5) && (pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
			while((depthSize > 0) && (pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
				TimeUnit.SECONDS.sleep(1);//delay for politeness policy
				doc_parse(nextUrl(),keyword);
				depthSize--;
			}
		
			System.out.print("\n-----------depth = "+depth+"----------Total Pages Visited = "+pagesVisited.size()+"--------\n");
			depth++;
			depthSize = frontierUrlList.size();
		}

		if(!(pagesVisited.size() < MAX_PAGES_TO_SEARCH)) {
			System.out.print("\nMaximum Pages limit of 1000 reached!\n");
		}
		else { System.out.print("\nMaximum Depth of 5 reached!\n");
		}

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1";	
		File customDir = new File(path,"Part 1 - Task 2A");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path += File.separator + "Part 1 - Task 2A";
		File ListOfLinks = new File(path,"0) ListOfLinks.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

		String ListOfLinksString = "\n";
		for (String item : pagesVisited) {
			ListOfLinksString += item +"\n";
		}

		out.append(ListOfLinksString);
		out.close();

		File Top5ListOfLinks = new File(path,"0) Top5ListOfLinks.txt");
		out = new BufferedWriter(new FileWriter(Top5ListOfLinks));
		String Top5ListOfLinksString = "\n";
		for (String item : top5PagesVisited) {
			Top5ListOfLinksString += item +"\n";
		}

		out.append(Top5ListOfLinksString);
		out.close();

	}

	public static void dfsTraversal(String url, String keyword, int depth) throws IOException, InterruptedException {

//		TimeUnit.SECONDS.sleep(1);//delay for politeness policy

		if(depth<=5){
			Document doc = null;
			String frontierUrl; 
			doc = fetchWebPage(url);
			Elements links = doc.select("a[href]");

			for (Element link : links) {

				if(pagesVisited.size()>=MAX_PAGES_TO_SEARCH || depth>5)
					break;
				if(((link.attr("abs:href").startsWith(urlPrefix)))) {
					frontierUrl = (link.attr("abs:href").replace(urlPrefix," "));
					if(!(frontierUrl.contains(":"))) {  						
						frontierUrl = (frontierUrl.split("#"))[0];						
						frontierUrl = urlPrefix +frontierUrl.trim();				
						if (frontierUrlLookupSet.add(frontierUrl)) {
							if(!pagesVisited.contains(frontierUrl)) {
								if(frontierUrl.contains(keyword) || link.text().contains(keyword))
									frontierUrlList.add(frontierUrl);
								else	
									if((checkForKeyword(frontierUrl,keyword))) {
										if(pagesVisited.size()==1000) return;
										frontierUrlList.add(frontierUrl);
										pagesVisited.add(frontierUrl);
										if(top5PagesVisited.size()<=5)
											top5PagesVisited.add(frontierUrl);
										dfsTraversal(frontierUrl,keyword,depth+1);
										depth--;
									}
							}
						}
					}
				}
			}
		}
		else return;
	}

	public static void dfs(String url, String keyword) throws InterruptedException, IOException {

		int depth = 1;

		System.out.print("\n-----------DFS procedure Focused Crawling----------\n");

		pagesVisited.add(url);
		top5PagesVisited.add(url);
		dfsTraversal(url,keyword,depth);

		if(!(pagesVisited.size() < MAX_PAGES_TO_SEARCH)) {
			System.out.print("\nMaximum Pages limit of 1000 reached!\n");
		}
		else {
			System.out.print("\nMaximum Depth of 5 reached!\n");
		}

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1";
		File customDir = new File(path,"Part 1 - Task 2B");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path += File.separator + "Part 1 - Task 2B";
		File ListOfLinks = new File(path,"ListOfLinks.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

		String ListOfLinksString = "\n";
		for (String item : pagesVisited) {
			ListOfLinksString += item +"\n";
		}

		out.append(ListOfLinksString);
		out.close();

		File Top5ListOfLinks = new File(path,"Top5ListOfLinks.txt");
		out = new BufferedWriter(new FileWriter(Top5ListOfLinks));
		String Top5ListOfLinksString = "\n";
		for (String item : top5PagesVisited) {
			Top5ListOfLinksString += item +"\n";
		}

		out.append(Top5ListOfLinksString);
		out.close();

	}
	
	public static void main(String[] args) throws Exception {

		String seed = "https://en.wikipedia.org/wiki/Sustainable_energy";
		String keyword = "solar";

//		bfs(seed,keyword);
//		clearDataStr();
		dfs(seed,keyword);

	}
}