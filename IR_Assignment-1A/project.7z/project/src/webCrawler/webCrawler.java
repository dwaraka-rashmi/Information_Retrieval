package webCrawler;

import java.io.*;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class webCrawler{

	static String urlPrefix = "https://en.wikipedia.org/wiki/";

	static Set<String> pagesVisited = new HashSet<String>();
	static List<String> frontierUrlList = new LinkedList<String>();
	static Set<String> frontierUrlLookupSet = new HashSet<String>();
	static int fileCount = 1;

	public static Document fetchWebPage(String url){
		Document doc = null;
		try {
			doc = Jsoup.connect(url).header("Accept-Encoding", "gzip, deflate").maxBodySize(0).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return doc;
	}

	public static void downloadWebPage(Document doc, String url) throws IOException{
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1";
		String article = url+"\n\n\n"+doc.html();

		File customDir = new File(path,"Part 1 - Task 1");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path += File.separator + customDir.getName();
		url = url.replace(urlPrefix," ");
		url = url.replace("\\", "-").trim();
		url = url.replace("/", "-").trim();
		String fileName = (fileCount++)+") "+url+".txt";

		File textFile = new File(path, fileName);
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		out.append(article);
		out.close();
	}

	public static String nextUrl(){
		String nextUrl;
		do{
			nextUrl = frontierUrlList.remove(0); 
		} while(pagesVisited.contains(nextUrl));
		pagesVisited.add(nextUrl);
		return nextUrl;
	}

	public static void getFrontierUrlList(String url) throws IOException {

		String frontierUrl; 
		Document doc = null;
		doc= fetchWebPage(url);
		downloadWebPage(doc,url);

		Elements links = doc.select("a[href]");

		for (Element link : links) {
			if(((link.attr("abs:href").startsWith(urlPrefix)))) {   
				frontierUrl = (link.attr("abs:href").replace(urlPrefix," "));
				if(!(frontierUrl.contains(":"))) {  
					frontierUrl = (frontierUrl.split("#"))[0];
					frontierUrl = urlPrefix +frontierUrl.trim();
					if (frontierUrlLookupSet.add(frontierUrl)) {
						if(!pagesVisited.contains(frontierUrl)) {
							frontierUrlList.add(frontierUrl);
						}
					}
				}
			}	
		}
	}


	public static void main(String[] args) throws Exception {

		int MAX_PAGES_TO_SEARCH = 1001;
		int depth = 1;
		String seed = "https://en.wikipedia.org/wiki/Sustainable_energy";

		getFrontierUrlList(seed);
		pagesVisited.add(seed);
		System.out.print("\n-----------depth = "+depth+"----------Total Pages Visited = 1--------\n");
		depth++;
		int depthSize = frontierUrlList.size();

		while( (depth <=5) && (pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
			while((depthSize > 0) && (pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
//				TimeUnit.SECONDS.sleep(1);//delay for politeness policy
				getFrontierUrlList(nextUrl());
				depthSize--;
			}
			System.out.print("\n-----------depth = "+depth+"----------Total Pages Visited = "+pagesVisited.size()+"--------\n");
			depth++;
			depthSize = frontierUrlList.size();
		}

		if(!(pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
			System.out.print("\nMaximum Pages limit of 1000 reached!\n");
		}
		else{
			System.out.print("\nMaximum Depth of 5 reached!\n");
		}

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1";	
		path += File.separator + "Part 1 - Task 1";
		File textFile = new File(path,"0) ListOfLinks.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		String ListOfLinks = "\n";
		for (String item : pagesVisited) {
			ListOfLinks += item +"\n";
		}
		out.append(ListOfLinks);
		out.close();
	}
}