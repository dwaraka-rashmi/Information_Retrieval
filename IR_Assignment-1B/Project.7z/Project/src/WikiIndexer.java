
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;


public class WikiIndexer {

	public static LinkedHashMap<String,LinkedList<String>> indexMap = new LinkedHashMap<String,LinkedList<String>>();
	public static LinkedHashMap<String,LinkedHashMap<String,Integer>> invertedIndex = 
			new LinkedHashMap<String,LinkedHashMap<String,Integer>>();
	public static Set<String> uniqueterms = new HashSet<String>();
	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static LinkedList<String> documentCollection = new LinkedList<String>();

	public static void readDataCollection(String corpusFile) throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1B";
//		path += File.separator + "tccorpus.txt";
		path += File.separator + corpusFile;

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);

		String inData = " ";
		String [] valueList;
		Boolean docFlag;
		String docId = "";
		Pattern pattern = Pattern.compile("\\d+");

		while (( inData = in.readLine()) != null) {
			docFlag = false;
			valueList = inData.split(" ");
			if(inData.startsWith("#")) {
				docId = valueList[1];
				indexMap.put(docId,new LinkedList<String>());
				documentCollection.push(docId);
				docFlag = true;
			}
			if(!docFlag) {
				for(String term : valueList){
					if(!(pattern.matcher(term).matches())) {
						indexMap.get(docId).add(term);
						uniqueterms.add(term); 
						// System.out.print("\n"+term);
					}
				}
			}
		}

		for(String term : uniqueterms) {
			vocabulary.add(term);
		}

		Collections.sort(vocabulary);
		Collections.reverse(documentCollection);
		//Collections.sort(documentCollection);
		in.close();
		System.out.print("\n vocabulary size "+vocabulary.size());
		System.out.print("\n documentCollection size "+documentCollection.size());

	}
	
	public static void buildInvertedIndex() {

		String doc;
		int tf = 0;

		for(String term : vocabulary) {
			LinkedHashMap<String,Integer> termFrequency = new LinkedHashMap<String,Integer>();
			for(String docId : documentCollection) {
				tf = Collections.frequency(indexMap.get(docId),term);
				if(tf>0) {
					termFrequency.put(docId, tf);
				}
			}
			invertedIndex.put(term, termFrequency);
			//System.out.print("\n"+term+" ");
			//termFrequency.clear();
		}

	}

	public static void main(String[] args) throws Exception {

		readDataCollection("wikiCorpus1.txt");
		buildInvertedIndex();

		String index = "";
		int i = 0;

		for (Entry<String, LinkedHashMap<String, Integer>> pos : invertedIndex.entrySet()) {
			index += pos.getKey()+" -> ";
			LinkedHashMap<String, Integer> posting = pos.getValue();
			for(Entry<String, Integer> e : posting.entrySet())
			{
			  index += "("+e.getKey()+"="+e.getValue()+"),";
			}
			//index = index.substring(0, (index.length()-1));
			index+= "\n";
			System.out.print("\n"+pos.getKey());
		}
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1B";

		//File ListOfLinks = new File(path,"indexTC.out");
		File ListOfLinks = new File("wikiInvertedIndex.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

		out.append(index);
		out.close();
		
		System.out.print("\n Inverted Index created");
		System.out.print("\n vocabulary size "+vocabulary.size());
		System.out.print("\n documentCollection size "+documentCollection.size());

		
	}
}
