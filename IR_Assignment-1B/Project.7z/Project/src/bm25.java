
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.regex.Pattern;

public class bm25 {

	public static LinkedHashMap<String,LinkedHashMap<String,Integer>> invertedIndex = 
			new LinkedHashMap<String,LinkedHashMap<String,Integer>>();
	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static LinkedList<String> documentCollection = new LinkedList<String>();
	public static LinkedHashMap<String,LinkedList<String>> queryTerms = new LinkedHashMap<String,LinkedList<String>>();
	public static LinkedHashMap<String,Double> Ranking = new LinkedHashMap<String,Double>();
	public static Double AvgDocLength;
	public static LinkedHashMap<String,LinkedHashMap<String,Double>> vectorDij = 
			new LinkedHashMap<String,LinkedHashMap<String,Double>>();

	public static void readQueries(String queryFile) throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1B";
		//path += File.separator + "queries.txt";
		path += File.separator + queryFile;

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);
		String inData = " ";
		String [] valueList;
		String [] valueList1;
		//LinkedList<String> value = new LinkedList<String>();
		String q = "";
		while ((inData = in.readLine()) != null) {
			//System.out.print(inData+"\n");
			valueList = inData.split("\t");
			q = valueList[0];
			queryTerms.put(q, new LinkedList<String>());
			valueList1 = valueList[1].split(" "); 
			LinkedList<String> value = new LinkedList<String>();
			for(int i = 0; i<valueList1.length;i++) {
				value.add(valueList1[i]);
				//System.out.print(valueList[i]);
			}
			queryTerms.put(q,(value));

		}
	}

	public static void readInvertedIndex(String indexFile) throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1B";
		//path += File.separator + "indexTC.out";
		path += File.separator + indexFile;

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);

		String inData = " ";
		String [] valueList;
		String term;
		String tf;
		String [] indexPosting;
		String [] posting;

		HashSet<String> docSet = new HashSet<String>(); 

		String docId = "";
		Pattern pattern = Pattern.compile("\\d+");

		while (( inData = in.readLine()) != null) {
			indexPosting = inData.split(" ");
			term = indexPosting[0];
			vocabulary.add(term);
			valueList = indexPosting[2].split(",");
			LinkedHashMap<String,Integer> termFrequency = new LinkedHashMap<String,Integer>();
			for(String docTfPair : valueList){
				posting = docTfPair.split("=");
				docId = posting[0].replace("(", "");
				docId = docId.trim();
				docSet.add(docId);
				//documentCollection.add(docId);
				tf = posting[1].replace(")","");
				tf = tf.trim();
				termFrequency.put(docId, Integer.parseInt(tf));
			}
			invertedIndex.put(term, termFrequency);

		}

		for(String doc : docSet) {
			documentCollection.add(doc);
		}

		Collections.sort(vocabulary);
		Collections.sort(documentCollection);
		in.close();
		System.out.print("\n vocabulary size "+vocabulary.size());
		System.out.print("\n documentCollection size "+documentCollection.size());

	}

	public static Integer docLength(String doc) {

		Integer length = 0;
		for (Entry<String, LinkedHashMap<String, Integer>> pos : invertedIndex.entrySet()) {
			LinkedHashMap<String, Integer> posting = pos.getValue();
			for(Entry<String, Integer> e : posting.entrySet())
			{
				if(doc.contentEquals(e.getKey())) {
					length += e.getValue();
				}
			}
		}
		return length;
	}

	public static void AverageDocLength()
	{
		Integer TotalDocLength = 0;

		for(String doc : documentCollection) {
			TotalDocLength += docLength(doc);
		}
		AvgDocLength = (double) (((double)TotalDocLength)/(double)documentCollection.size());
		System.out.print("\n Average doc length "+AvgDocLength);

	}


	public static double calcPart1(String word){

		Double D = (double)documentCollection.size();
		Double logNumerator = (double)D+0.5;
		Double Dfw = (double)invertedIndex.get(word).size();
		Double logDenominator = (double)Dfw+0.5;
		//System.out.print("\npart1 "+((double)(Math.log(logNumerator/logDenominator))));
		return ((double)(Math.log(logNumerator/logDenominator)));

	}

	public static double calcPart2(String word,String doc){

		Double k1 = (double)1.2;
		Double b = (double)0.75;
		Double lenDAvgD = (double)docLength(doc)/AvgDocLength;
		LinkedHashMap<String, Integer> posting = invertedIndex.get(word);
		Double tf = (double)posting.get(doc);
		Double numerator = ((double)tf+k1*tf);
		Double denominator = ((double)tf+(k1*((1-b)+(b*lenDAvgD))));
		//System.out.print("\npart2 "+(double)numerator/denominator);
		return (double)numerator/denominator;

	}

	public static double calcPart3(String query,String word){

		Double tf = (double)Collections.frequency(queryTerms.get(query),word);
		Double k2 = (double)100;
		Double numerator = (double)tf+(k2*tf);
		Double denominator = (double)tf+k2;
		//System.out.print("\npart3 "+(double)numerator/denominator);
		return (double)numerator/denominator;

	}


	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {

		readInvertedIndex(args[0]);
		readQueries(args[1]);
		AverageDocLength();
		Double Rank = 0.0;

		for(Entry e : queryTerms.entrySet()) {

			String Result = "";
			Result += "\nQuery : "+e.getKey()+"\n";

			System.out.print("\nFor Query"+e.getKey());
			String query = (String) e.getKey();
			//			String doc = "3127";
			for(String doc :documentCollection) {	
				Rank = 0.0;
				for(String word : queryTerms.get(query)) {

					if(invertedIndex.get(word).containsKey(doc)) 
						Rank += (double)(calcPart1(word)*calcPart2(word,doc)*calcPart3(query,word));
					else
						Rank += 0.0;
				}

				Ranking.put(doc, Rank);

			}	

			List list = new LinkedList(Ranking.entrySet());

			Collections.sort(list, new Comparator() {
				public int compare(Object o1, Object o2) {
					return ((Comparable) ((Map.Entry) (o1)).getValue())
							.compareTo(((Map.Entry) (o2)).getValue());
				}	
			});

			Collections.reverse(list);

			LinkedHashMap sortedPR = new LinkedHashMap();
			for (Iterator i = list.iterator(); i.hasNext();) {
				Map.Entry entry = (Map.Entry) i.next();
				sortedPR.put(entry.getKey(), entry.getValue());
			} 

			String Top10 = "\n";
			Set sortedPRSet = sortedPR.entrySet();
			Iterator iterator = sortedPRSet.iterator();
			int i = 0;
			while(iterator.hasNext()) {
				Map.Entry me = (Map.Entry)iterator.next();
				Result += me.getKey()+"="+me.getValue()+"\n";
				if(i==Integer.parseInt(args[2])){
					break;
				}
				i++;
			}
			i = 0;
			while(iterator.hasNext()) {
				Map.Entry me = (Map.Entry)iterator.next();
				Top10 += me.getKey()+"="+me.getValue()+"\n";
				if(i==Integer.parseInt(args[2])){
					break;
				}
				i++;
			}

			System.out.print(Top10);

			String path = System.getProperty("user.home") + File.separator + "Documents";
			path += File.separator + "IR Assignment 1B";

			File ListOfLinks = new File(path,"resultsBM25_"+e.getKey()+".eval");
			BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

			out.append(Result);
			out.close();

			System.out.print("\n"+"resultsBM25_"+e.getKey()+".eval created");

		}

	}


}
