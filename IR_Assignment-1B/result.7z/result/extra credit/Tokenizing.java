import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.regex.Pattern;

import org.tartarus.snowball.ext.EnglishStemmer;


public class Tokenizing{

	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static HashSet<String> vocabularySet = new HashSet<String>();
	public static LinkedList<String> vocabularyStemmed = new LinkedList<String>();
	public static LinkedList<String> documentCollection = new LinkedList<String>();
	public static LinkedList<String> stopWords = new LinkedList<String>();
	
	
	//title/header/p
	public static void readFilesTokenize() throws IOException {
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1B";
		path += File.separator + "Wiki";
		String corpus = "";
		
		final File files = new File(path);
		int i = 1;
		for (File fileEntry : files.listFiles()) {

			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
			String document = "";
			Pattern pattern = Pattern.compile("\\w+(.?\\w+)*");
			
			while (( inData = in.readLine()) != null) {
				document += inData;
			}
			
			Document doc = Jsoup.parse(document); 
				
				String text = "";
				Elements elements = doc.getAllElements();;

				for (Element element : elements) {
					if(element.tagName()=="p"||element.tagName()=="title"||element.tagName().matches("h\\d"))
					//if(element.tagName().matches("h\\d"))	
					text += " "+element.text();
					//System.out.println(element.text());
				}
				
				String[] tokens = text.split("[^\\w.]");

				for(String t : tokens) {
					t = t.trim();
					t = t.toLowerCase();
					if(pattern.matcher(t).matches()) {
						vocabulary.add(t);
					}
				}
				
				Stemming();
				Stopping();
				
				String filename = fileEntry.getName();
				filename = filename.split(" ")[1];
				filename = filename.replace(".txt", "");
				
				corpus += "\n"+"# "+filename+"\n";
				String termList = "";
				for(String term : vocabularyStemmed) {
					termList += term+" ";
				}
				//System.out.print("\n"+termList);
				corpus += termList.trim();
				//System.out.print("\n"+corpus);
				
				System.out.print("\n file "+(i++)+" "+filename);
				
		}
		
		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 1B";

		File ListOfLinks = new File(path1,"wikiCorpus.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

		out.append(corpus);
		out.close();
		
		System.out.print("\n corpus created");
		
	}
	
	public static void Stopping() throws IOException {
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 1B";
		path += File.separator + "stopwords.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);
		String inData = " ";
		String [] valueList;
		String document = "";
		
		while (( inData = in.readLine()) != null) {
			stopWords.add(inData.trim());
		}		
		
		for(int i = 0;i<vocabularyStemmed.size();i++) {
			
			if(stopWords.contains(vocabularyStemmed.get(i)))
				vocabularyStemmed.remove(i);
		}
		
	}
	
	public static void Stemming() {
		
		vocabularyStemmed.clear();
		//LinkedList<String> list = new LinkedList<String>();
		for(String term : vocabulary) {
		    EnglishStemmer stemmer = new EnglishStemmer();
		    stemmer.setCurrent(term);
		    if (stemmer.stem()){
		    	vocabularyStemmed.add(stemmer.getCurrent());
		    }
		}
		vocabulary.clear();

	}
	
	public static void main(String[] args) throws Exception {
		
		readFilesTokenize();
		
		
	}

}

