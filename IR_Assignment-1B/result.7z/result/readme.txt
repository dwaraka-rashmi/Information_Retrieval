Run the below commands in a command prompt using java commands

Place the tccorpus.txt and queries.txt in the 
<user.home>/Documents/IR Assignment 1B.
The results indexTC.out files gets stored in the above folder

kindly run the command with java 

1) indexer tccorpus.txt indexTC.out
2) vsm1 indexTC.out queries.txt 100 > resultsVSM1.eval
3) vsm2 indexTC.out queries.txt 100 > resultsVSM2.eval
4) bm25 indexTC.out queries.txt 100 > resultsBM25.eval


For Extra credits, index creation, I have used snowball 
stemmer from java weka project. I have also included jar 
file used to stem. Also i have used Jsoup

