
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

//import org.apache.lucene.analysis.en.EnglishAnalyzer;
//import org.apache.lucene.analysis.util.StopwordAnalyzerBase;

public class indexer {

	public static LinkedHashMap<String,LinkedList<String>> indexMap = new LinkedHashMap<String,LinkedList<String>>();
	public static LinkedHashMap<String,LinkedHashMap<String,Integer>> invertedIndex = 
			new LinkedHashMap<String,LinkedHashMap<String,Integer>>();
	public static Set<String> uniqueterms = new HashSet<String>();
	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static LinkedList<String> documentCollection = new LinkedList<String>();
	public static LinkedList<String> stopWords = new LinkedList<String>();
	//			The default stop words set in StandardAnalyzer and EnglishAnalyzer is
	//	        from StopAnalyzer.ENGLISH_STOP_WORDS_SET, and they are:
	//
	//			"a", "an", "and", "are", "as", "at", "be", "but", "by",
	//			"for", "if", "in", "into", "is", "it",
	//			"no", "not", "of", "on", "or", "such",
	//			"that", "the", "their", "then", "there", "these",
	//			"they", "this", "to", "was", "will", "with"
	
	public static void readStopWords() throws IOException {
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";
		path += File.separator + "stopWords.txt";
//		path += File.separator + queryFile;

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);
		String inData = " ";
		String [] valueList;
		String [] valueList1;

		String q = "";
		while ((inData = in.readLine()) != null) {
			stopWords.add(inData);
		}
	}

	//	public static void readDataCollection(String corpusFile) throws IOException {
	public static void readDataCollection() throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";
		//path += File.separator + "tccorpus.txt";
		path += File.separator + "corpus";
		final File files = new File(path);
		int i = 1;
		for (File fileEntry : files.listFiles()) {

			//fileEntry = "C:\\Users\Rashmi Dwaraka\Documents\IR Assignment 3\corpus\CACM-3055.html";
			//FileReader file = new FileReader(path+File.separator+"CACM-3055.html");
			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
			String corpus;
			Boolean docFlag;
			String docId = "";
//			Pattern pattern = Pattern.compile("\\d+\\t+"); //"100	5	1"
//			Pattern pattern = Pattern.compile("\\w+(.?\\w+*");
//			Pattern pattern = Pattern.compile("[a-z0-9]+(.?[a-z0-9]+)*");
			Pattern pattern = Pattern.compile("\\w+(.?\\w+)*");

			//System.out.print(pattern.matcher("aa.a").matches());
			String filename = fileEntry.getName();
			docId = filename.replace(".html", "");
			documentCollection.push(docId);
			indexMap.put(docId,new LinkedList<String>());

			//corpus += "\n"+"# "+filename+"\n";
			while (( inData = in.readLine()) != null) {
//				if((!(inData.startsWith("<")&&inData.endsWith(">")))||!(pattern.matcher(inData).matches())){
				if(!(inData.startsWith("<")&&inData.endsWith(">"))) {	
					valueList = inData.split("[^\\w.]");

					for(String term : valueList) {

						term = term.toLowerCase();
						if(term.endsWith(".")) 
							term = term.substring(0,term.length()-1);
						if((!stopWords.contains(term))&&(pattern.matcher(term).matches())) {
							indexMap.get(docId).add(term);
							uniqueterms.add(term); 
							//System.out.print("\n"+term);
						}
					}
				
				}
			}
			
			System.out.print("\n"+docId);

			in.close();
//			break;
		}

		for(String term : uniqueterms) {
			vocabulary.add(term);
		}

		Collections.sort(vocabulary);
		Collections.reverse(documentCollection);
		//Collections.sort(documentCollection);

		System.out.print("\n vocabulary size "+vocabulary.size());
		System.out.print("\n documentCollection size "+documentCollection.size());

	}

	public static void buildInvertedIndex() {

		String doc;
		int tf = 0;

		for(String term : vocabulary) {
			LinkedHashMap<String,Integer> termFrequency = new LinkedHashMap<String,Integer>();
			for(String docId : documentCollection) {
				tf = Collections.frequency(indexMap.get(docId),term);
				if(tf>0) {
					termFrequency.put(docId, tf);
				}
			}
			invertedIndex.put(term, termFrequency);
			//System.out.print("\n"+term+" ");
			//termFrequency.clear();
		}

	}

	public static void main(String[] args) throws Exception {

		//		readDataCollection(args[0]);4
		readStopWords();
		readDataCollection();
		buildInvertedIndex();

		String index = "";
		int i = 0;

		for (Entry<String, LinkedHashMap<String, Integer>> pos : invertedIndex.entrySet()) {
			index += pos.getKey()+" -> ";
			LinkedHashMap<String, Integer> posting = pos.getValue();
			for(Entry<String, Integer> e : posting.entrySet())
			{
				index += "("+e.getKey()+"="+e.getValue()+"),";
			}
			index = index.substring(0, (index.length()-1));
			index+= "\n";
			System.out.print("\n"+pos.getKey());
//			index += "\n"+pos.getKey();
		}

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";

		File ListOfLinks = new File(path,"indexTC.out");
		//		File ListOfLinks = new File(path,args[1]);
		BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

		out.append(index);
		out.close();

		System.out.print("\n Inverted Index created");


	}
}
