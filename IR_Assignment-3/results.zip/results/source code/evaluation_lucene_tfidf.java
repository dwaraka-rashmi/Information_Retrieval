
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedList;

public class evaluation_lucene_tfidf {
	
	public static LinkedHashMap<String,LinkedList<String>> RelDoc = new LinkedHashMap<String,LinkedList<String>>();
	public static LinkedHashMap<String,LinkedList<String>> documentCollectionRetrieved = new LinkedHashMap<String,LinkedList<String>>();
	
	public static void readRelJudgments() throws IOException {
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";
		path += File.separator + "relevance_judgments.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);
		String inData = " ";
		String [] valueList;

		String q = "";
		while ((inData = in.readLine()) != null) {
			valueList = inData.split(" ");
			q = valueList[0];
			LinkedList<String> value = new LinkedList<String>();
			if(!(RelDoc.keySet().contains(q)))
			{
				System.out.print("\n"+valueList[0]);
				RelDoc.put(q, new LinkedList<String>());
				for(String val : valueList) {
					if(val.startsWith("CACM-")) {
						value = RelDoc.get(q);
						value.add(val);
						RelDoc.put(q,value);	
						System.out.print(" "+val);
					}
				}
			}
			else 
				for(String val : valueList) {
					if(val.startsWith("CACM-")) {
						value = RelDoc.get(q);
						value.add(val);
						RelDoc.put(q,value);	
						System.out.print(" "+val);
					}
				}
		}
		
		in.close();
	}
	
	public static void readdocumentRetrieved() throws IOException {
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";
		path += File.separator + "Lucene_default";
		final File files = new File(path);
		
		for (File fileEntry : files.listFiles()) {

			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String query ="";
			
			LinkedList<String> docList = new LinkedList<String>();

			String filename = fileEntry.getName();
			query = filename.replace("_lucene_default.eval","");

			documentCollectionRetrieved.put(query,new LinkedList<String>());

			while (( inData = in.readLine()) != null) {
				if(inData.startsWith("CACM-"))
					docList.add(inData);
			}
			
			documentCollectionRetrieved.put(query, docList);
			System.out.print("\n"+query);
					
		}
	}
	
	public static double precision_at_n(int n, String q){

		int count = 0;
		LinkedList<String> rel = new LinkedList<String>();
		for(String retdocs : documentCollectionRetrieved.get(q)) {
			if(RelDoc.get(q).contains(retdocs)){
				rel.add(retdocs);
			}
			count++;
			if(count==n) break;
		}
		
		Double Precision = ((double)rel.size())/n;
		return ((double)Precision);
	}

	public static void main(String[] args) throws Exception {

		readRelJudgments();
		readdocumentRetrieved();
		Double Precision;
		Double Recall;
		Double F1;

		double TotalPrecision_at_n = 0;
		for(String q : documentCollectionRetrieved.keySet())
		{
			LinkedList<String> rel = new LinkedList<String>();
			for(String reldocs : RelDoc.get(q)) {
				if(documentCollectionRetrieved.get(q).contains(reldocs)){
					rel.add(reldocs);
				}
			}

			System.out.print("\nquery"+q+"\n");
			System.out.print(q+" "+rel.size());

			Precision = ((double)rel.size())/((double)documentCollectionRetrieved.get(q).size());
			Recall = ((double)rel.size())/((double)RelDoc.get(q).size());
			F1 = ((double)2*Precision*Recall)/((double)Precision+Recall);
			System.out.print("\nPrecision "+Precision);
			System.out.print("\nRecall "+Recall);
			System.out.print("\nF1 "+F1+"\n");
			int[] nList = {5, 10, 20, 30, 50, 70, 100};

			double AvgPrecision_at_n = 0;
			for(int i : nList) {
				AvgPrecision_at_n += precision_at_n(i,q);
				System.out.println("prec@n "+i+" "+precision_at_n(i,q));
			}
			TotalPrecision_at_n += AvgPrecision_at_n/7;
//			System.out.print("\nAvgPrecision_at_n "+AvgPrecision_at_n);
			System.out.print("\nAvgPrecision_at_n "+AvgPrecision_at_n/7);


		}
		
		Double MAP = TotalPrecision_at_n/5;
		System.out.print("\nMAP "+MAP);

	}
}