
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.regex.Pattern;

public class vsm1 {
	public static LinkedHashMap<String,LinkedHashMap<String,Integer>> invertedIndex = 
			new LinkedHashMap<String,LinkedHashMap<String,Integer>>();
	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static LinkedList<String> documentCollection = new LinkedList<String>();
	public static LinkedHashMap<String,LinkedList<String>> queryTerms = new LinkedHashMap<String,LinkedList<String>>();
	public static LinkedHashMap<String,Double> Ranking = new LinkedHashMap<String,Double>();
	public static Double AvgDocLength;
	
	public static void readQueries() throws IOException {
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";
		path += File.separator + "queries.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);
		String inData = " ";
		String [] valueList;

		String q = "";
		while ((inData = in.readLine()) != null) {
			valueList = inData.split(" ");
			q = valueList[0];
			//System.out.print("\n"+valueList[0]);
			queryTerms.put(q, new LinkedList<String>());
			LinkedList<String> value = new LinkedList<String>();
			for(int i = 1; i<valueList.length;i++) {
				value.add(valueList[i]);
				//System.out.print("\n"+valueList[i]);
			}
			queryTerms.put(q,(value));
			
		}
		
		in.close();
	}

	public static void readInvertedIndex() throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 3";
		path += File.separator + "indexTC.out";
		
		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);

		String inData = " ";
		String [] valueList;
		String term;
		String tf;
		String [] indexPosting;
		String [] posting;
		
		HashSet<String> docSet = new HashSet<String>(); 
		
		String docId = "";
//		Pattern pattern = Pattern.compile("\\d+");

		while (( inData = in.readLine()) != null) {
			indexPosting = inData.split(" ");
			term = indexPosting[0];
			vocabulary.add(term);
			valueList = indexPosting[2].split(",");
			LinkedHashMap<String,Integer> termFrequency = new LinkedHashMap<String,Integer>();
			for(String docTfPair : valueList){
			   	posting = docTfPair.split("=");
			   	docId = posting[0].replace("(", "");
			   	docId = docId.trim();
			   	docSet.add(docId);
			   	//documentCollection.add(docId);
			   	tf = posting[1].replace(")","");
			   	tf = tf.trim();
			   	termFrequency.put(docId, Integer.parseInt(tf));
			}
			invertedIndex.put(term, termFrequency);
			
		}
		
		for(String doc : docSet) {
			documentCollection.add(doc);
		}
		
		Collections.sort(vocabulary);
		Collections.sort(documentCollection);
		in.close();
		System.out.print("\n vocabulary size "+vocabulary.size());
		System.out.print("\n documentCollection size "+documentCollection.size());

	}
	
	public static Integer docLength(String doc) {
		
		Integer length = 0;
		for (Entry<String, LinkedHashMap<String, Integer>> pos : invertedIndex.entrySet()) {
			LinkedHashMap<String, Integer> posting = pos.getValue();
			for(Entry<String, Integer> e : posting.entrySet())
			{
				if(doc.contentEquals(e.getKey())) {
			       length += e.getValue();
				}
			}
		}
		return length;
	}
	
	public static void AverageDocLength()
	{
		Integer TotalDocLength = 0;
		 
		for(String doc : documentCollection) {
			TotalDocLength += docLength(doc);
		}
		AvgDocLength = (double) (((double)TotalDocLength)/(double)documentCollection.size());
		System.out.print("\n Average doc length "+AvgDocLength);
		
	}

	public static double okapi_tf(String word, String doc) {
		
		LinkedHashMap<String, Integer> posting = invertedIndex.get(word);
		Double tf = (double) posting.get(doc);
		return ((double)tf/((double)(tf+ 0.5 + ((double)(1.5*((double)docLength(doc)/AvgDocLength))))));
		
	}
	
	public static Integer docFrequency(String word){
		
		LinkedHashMap<String, Integer> posting = invertedIndex.get(word);
		return posting.size();	
	}
	
	public static void calcRank(String query) {
		
		for(String doc : documentCollection) {
			Ranking.put(doc, (double) 0.0);
		}
		
		Double Rank;
		String word;
		Double logPart;
		for(String doc : documentCollection) {
			Rank = (double)Ranking.get(doc);	
			for(String e : queryTerms.get(query)) {
				word = e;
				Double D = (double)documentCollection.size();
				Double idf = ((double)invertedIndex.get(word).size());
				logPart = ((double)(Math.log((double)(D/idf))));
				if(invertedIndex.get(word).containsKey(doc))
					Rank += ((double)okapi_tf(word,doc)*logPart);
				else
					Rank += (double)0.0;
			}
			Ranking.put(doc, Rank);	
		}		
	}
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		
		readInvertedIndex();
		readQueries();
		AverageDocLength();

		for(Entry e : queryTerms.entrySet())
		{
			String Result = "";
			Result += "\nQuery : "+e.getKey()+"\n";
			System.out.print("\nFor Query"+e.getKey());
			calcRank((String)e.getKey());
			List list = new LinkedList(Ranking.entrySet());

			Collections.sort(list, new Comparator() {
				public int compare(Object o1, Object o2) {
					return ((Comparable) ((Map.Entry) (o1)).getValue())
							.compareTo(((Map.Entry) (o2)).getValue());
				}
			});

			Collections.reverse(list);

			LinkedHashMap sortedPR = new LinkedHashMap();
			for (Iterator i = list.iterator(); i.hasNext();) {
				Map.Entry entry = (Map.Entry) i.next();
				sortedPR.put(entry.getKey(), entry.getValue());
			} 

			String Top10 = "\n";
			Set sortedPRSet = sortedPR.entrySet();
			Iterator iterator = sortedPRSet.iterator();
			int i = 1;
			while(iterator.hasNext()) {
				Map.Entry me = (Map.Entry)iterator.next();
				if((double)me.getValue()>0.0)
//				Result += me.getKey()+"="+me.getValue()+"\n";
				Result += me.getKey()+"\n";
			}
			i = 1;
			while(iterator.hasNext()) {
				Map.Entry me = (Map.Entry)iterator.next();
				Top10 += "#"+me.getKey()+"="+me.getValue()+"\n";
				if(i==100){
					break;
				}
				i++;
			}
			
			System.out.print(Top10);
			String path = System.getProperty("user.home") + File.separator + "Documents";
			path += File.separator + "IR Assignment 3";

			File ListOfLinks = new File(path,e.getKey()+"_resultsVSM1_docs.eval");
			BufferedWriter out = new BufferedWriter(new FileWriter(ListOfLinks));

			out.append(Result);
			out.close();
			
			System.out.print("\n"+"resultsVSM1_"+e.getKey()+".eval created");

		}
				
	}
	
}