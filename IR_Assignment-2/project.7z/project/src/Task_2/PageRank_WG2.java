package Task_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class PageRank_WG2 {

	static LinkedHashMap<String,ArrayList> inLinkMap = new LinkedHashMap<String,ArrayList>();

	public static Integer outLinkCount(String page){
		int count = 0;
		for(Entry e : inLinkMap.entrySet()) {
			if(inLinkMap.get(e.getKey()).contains(page))
				count++;
		}
		return count;
	}
	public static Boolean sinkNode(String page){
		Boolean flag = true;
		for(Entry e : inLinkMap.entrySet()) {
			if(e.getValue().toString().contains(page))
			{	flag = false;
			break;
			}
		}
		return flag;
	}


	@SuppressWarnings({ "null", "unchecked", "rawtypes" })
	public static void main(String[] args) throws Exception {

		LinkedHashMap<String,Integer> inLinkCountMap = new LinkedHashMap<String,Integer>();
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 2";
		path += File.separator + "Task 1B";
		path += File.separator + "Task_1B-WG2.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);


		//String inData = "A D E F\nB A F\nC A B D\nD B C\nE B C D F\nF A B D";

		String inData = " ";
		String [] valueList;
		String key;

		while ((( inData = in.readLine()) != null)) {
			valueList = inData.split(" ");
			key = valueList[0];
			inLinkCountMap.put(valueList[0],(valueList.length-2));
			inLinkMap.put(key,new ArrayList<String>());
			for(int i = 1;i<valueList.length;i++) {
				if(!inLinkMap.get(key).contains(valueList[i]))
					inLinkMap.get(key).add(valueList[i]);
			}
		}

		System.out.print("\ninlinkMap "+inLinkMap.size());

		// P is the set of all pages; |P| = N
		int N = inLinkMap.size();

		Set<String> sinkNodes = new HashSet<String>();
		// L(q) is the number of out-links (without duplicates) from page q
		LinkedHashMap<String,Integer> outLinkCountMap = new LinkedHashMap<String,Integer>();

		for(Entry e : inLinkMap.entrySet())
		{
			if(sinkNode((String) e.getKey()))
			{
				sinkNodes.add((String) e.getKey());
				outLinkCountMap.put((String) e.getKey(),0);
			}
			else
				outLinkCountMap.put((String) e.getKey(),outLinkCount((String) e.getKey()));	
		}

		System.out.print("sink node done");


		System.out.print("outlink done");
		// d is the PageRank damping/teleportation factor; 
		//use d = 0.85 as a fairly typical value
		double d = (double) 0.85;

		// initial PageRank value  
		LinkedHashMap<String,Double> pageRankValue = new LinkedHashMap<String,Double>();
		LinkedHashMap<String,Double> newPR = new LinkedHashMap<String,Double>();		
		for(String link : inLinkMap.keySet()) {
			pageRankValue.put(link, ((double) 1/N));
			newPR.put(link,((double) 1/N));
		}

		double sumPR;
		double sinkPR;
		Boolean converged = false;
		ArrayList<Double> iteration = null;

		while(!converged){ 

			sinkPR = 0;
			for(String sink : sinkNodes) {
				sinkPR += pageRankValue.get(sink);
			}

			// M(p) is the set (without duplicates) of pages that link to page p
			ArrayList<String> m = new ArrayList<String>();
			
			for(Entry en : pageRankValue.entrySet()) {
				String keyPg = (String) en.getKey();
				newPR.put(keyPg,((double) ((double)1-d)/N));
				newPR.put(keyPg,(newPR.get(keyPg)+((double)((double)d*sinkPR)/N)));
				m = inLinkMap.get(keyPg);
				for(String pg : m) {
					newPR.put(keyPg,(((double)newPR.get(keyPg))+((double)((double)d*pageRankValue.get(pg))/outLinkCountMap.get(pg))));
				}
			}

			for(String page : pageRankValue.keySet()) {
				pageRankValue.put(page, newPR.get(page));
			}

			sumPR = 0;
			double pr = 0;
		
			for(String page : pageRankValue.keySet()){
				pr = pageRankValue.get(page);
				//System.out.print("\n"+page+" "+pr);
				sumPR += (pr)*(Math.log(pr)/Math.log(2));
			}
			//System.out.print("\nsumPR "+sumPR);
			if(iteration == null) {
				iteration = new ArrayList<Double>();
				iteration.add(Math.pow(2,(-(sumPR))));
			}
			else
				iteration.add(Math.pow(2,(-(sumPR))));
			//			count++;
			int count = 0;
			double convergence;
			if(iteration.size()>4){
				for(int i = iteration.size()-1;i>=(iteration.size()-4);i--) {
					
					convergence = (iteration.get(i) - iteration.get(i-1));
					if(Math.abs(convergence)<=1) count++;
					
				}
				if(count==4){
					converged = true;
				}
			}
		}
		System.out.print("\niteration converged at "+iteration.size());
		double totalPR = 0;
		for(String pg : pageRankValue.keySet())
		{
			totalPR+=pageRankValue.get(pg);
		}

		System.out.print("totalPR "+totalPR);

		List list = new LinkedList(pageRankValue.entrySet());

		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		LinkedHashMap sortedPR = new LinkedHashMap();
		for (Iterator i = list.iterator(); i.hasNext();) {
			Map.Entry entry = (Map.Entry) i.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		Set sortedPRSet = sortedPR.entrySet();
		Iterator iterator = sortedPRSet.iterator();
		int c = 0;
		String Top50_WG2 = " ";
		while(iterator.hasNext() && c<50) {
			c++;
			Map.Entry me = (Map.Entry)iterator.next();
			Top50_WG2 += me.getKey() + " : "+me.getValue()+"\n";
		}

		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 2";
		File customDir = new File(path1,"Task 2B");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path1 += File.separator + customDir.getName();

		File textFile = new File(path1,"Top50 WG2.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		out.append(Top50_WG2);
		out.close();

		String Perplexity = " ";
		int i =0;
		for(double val : iteration) { 
			Perplexity += "Iteration "+(i++)+" : "+val+"\n";
		}

		File textFile1 = new File(path1,"Perplexity - WG2.txt");
		BufferedWriter out1 = new BufferedWriter(new FileWriter(textFile1));

		out1.append(Perplexity);
		out1.close();
//-------------------------------------------------------------------------------------------------------------		
		//d=0.95
		d = (double) 0.95;

		System.out.print("\n0.95 iteration");
		// initial PageRank value  
		pageRankValue.clear();
		newPR.clear();		
		for(String link : inLinkMap.keySet()) {
			pageRankValue.put(link, ((double) 1/N));
			newPR.put(link,((double) 1/N));
		}

		sumPR = 0;
		converged = false;
		iteration = null;

		while(!converged){ 

			sinkPR = 0;
			for(String sink : sinkNodes) {
				sinkPR += pageRankValue.get(sink);
			}

			// M(p) is the set (without duplicates) of pages that link to page p
			ArrayList<String> m = new ArrayList<String>();
			
			for(Entry en : pageRankValue.entrySet()) {
				String keyPg = (String) en.getKey();
				newPR.put(keyPg,((double) ((double)1-d)/N));
				newPR.put(keyPg,(newPR.get(keyPg)+((double)((double)d*sinkPR)/N)));
				m = inLinkMap.get(keyPg);
				for(String pg : m) {
					newPR.put(keyPg,(((double)newPR.get(keyPg))+((double)((double)d*pageRankValue.get(pg))/outLinkCountMap.get(pg))));
				}
			}

			for(String page : pageRankValue.keySet()) {
				pageRankValue.put(page, newPR.get(page));
			}

			sumPR = 0;
			double pr = 0;
		
			for(String page : pageRankValue.keySet()){
				pr = pageRankValue.get(page);
				//System.out.print("\n"+page+" "+pr);
				sumPR += (pr)*(Math.log(pr)/Math.log(2));
			}
			//System.out.print("\nsumPR "+sumPR);
			if(iteration == null) {
				iteration = new ArrayList<Double>();
				iteration.add(Math.pow(2,(-(sumPR))));
			}
			else
				iteration.add(Math.pow(2,(-(sumPR))));
			//			count++;
			int count = 0;
			double convergence;
			if(iteration.size()>4){
				for(int n = iteration.size()-1;n>=(iteration.size()-4);n--) {
					
					convergence = (iteration.get(n) - iteration.get(n-1));
					if(Math.abs(convergence)<=1) count++;
					
				}
				if(count==4){
					converged = true;
				}
			}
		}
		System.out.print("\niteration converged at "+iteration.size());
		totalPR = 0;
		for(String pg : pageRankValue.keySet())
		{
			totalPR+=pageRankValue.get(pg);
		}

		System.out.print("\ntotalPR "+totalPR);

		list = new LinkedList(pageRankValue.entrySet());

		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		sortedPR = new LinkedHashMap();
		for (Iterator n = list.iterator(); n.hasNext();) {
			Map.Entry entry = (Map.Entry) n.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		sortedPRSet = sortedPR.entrySet();
		iterator = sortedPRSet.iterator();
		c = 0;
		String Top50_WG2_2 = " ";
		while(iterator.hasNext() && c<50) {
			c++;
			Map.Entry me = (Map.Entry)iterator.next();
			Top50_WG2_2 += me.getKey() + " : "+me.getValue()+"\n";
		}

		
		textFile = new File(path1,"Top50 WG2 0-95.txt");
		out = new BufferedWriter(new FileWriter(textFile));

		out.append(Top50_WG2_2);
		out.close();

		Perplexity = " ";
		i =0;
		for(double val : iteration) { 
			Perplexity += "Iteration "+(i++)+" : "+val+"\n";
		}

		textFile1 = new File(path1,"Perplexity - WG2 0-95.txt");
		out1 = new BufferedWriter(new FileWriter(textFile1));

		out1.append(Perplexity);
		out1.close();
		
		// inlink list
		System.out.print("\ninlink list");
		
		list = new LinkedList(inLinkCountMap.entrySet());
		
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		sortedPR = new LinkedHashMap();
		for (Iterator n = list.iterator(); n.hasNext();) {
			Map.Entry entry = (Map.Entry) n.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		sortedPRSet = sortedPR.entrySet();
		iterator = sortedPRSet.iterator();
		c = 0;
		String inLinkCount = " ";
		while(iterator.hasNext() && c<50) {
			c++;
			Map.Entry me = (Map.Entry)iterator.next();
			inLinkCount += me.getKey() + " : "+me.getValue()+"\n";
		}
	
		textFile = new File(path1,"WG2-inlinkCount.txt");
		out = new BufferedWriter(new FileWriter(textFile));

		out.append(inLinkCount);
		out.close();

	}
}
