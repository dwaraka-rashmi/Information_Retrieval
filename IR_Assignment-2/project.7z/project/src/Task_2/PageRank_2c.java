package Task_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

//A D E F
//B A F
//C A B D
//D B C
//E B C D F
//F A B C D
//G A C
//H C F
// 
//G and H will be the sink nodes, as they do not have out-going links.
//The Final ranking based on PageRank scores of the above 8 pages would be:
// 
//A>F>E>C>B>G>H>D

//A D E F
//B A F
//C A B D
//D B C
//E B C D F
//F A B D
//And the final ranking list would be: A>E>(F,C)>B>D (F and C have same Page Rank value)

public class PageRank_2c {

	static LinkedHashMap<String,ArrayList> inLinkMap = new LinkedHashMap<String,ArrayList>();

	@SuppressWarnings({ "null", "unchecked", "rawtypes" })
	public static void main(String[] args) throws Exception {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 2";
		path += File.separator + "Task 1B";
		path += File.separator + "Task_1B-WG2.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);

		String inData = "A D E F\nB A F\nC A B D\nD B C\nE B C D F\nF A B D";
		//String inData = "A D E F\nB A F\nC A B D\nD B C\nE B C D F\nF A B C D\nG A C\nH C F";
		String [] map;
		String [] valueList;
		String key;

		map = inData.split("\n");
		for(String item : map) {
			valueList = item.split(" ");
			key = valueList[0];
			//if(!inLinkMap.containsKey(valueList[0])) {
			inLinkMap.put(key,new ArrayList<String>());
			for(int i = 1;i<valueList.length;i++) {
				if(!inLinkMap.get(key).contains(valueList[i]))
					inLinkMap.get(key).add(valueList[i]);
			}
		}

		System.out.print("Directed Web Graph\n");
		for (String item : inLinkMap.keySet()) {
			System.out.print(item+" ");
			ArrayList<String> inlinks =  inLinkMap.get(item);
			for(String link : inlinks) {
				System.out.print(link+" ");
			}
			System.out.print("\n");
		}

		// P is the set of all pages; |P| = N
		int N = inLinkMap.size();

		// S is the set of sink nodes, i.e., pages that have no out links
		Set<String> sinkNodes = new HashSet<String>();
		ArrayList<String> value;

		// L(q) is the number of out-links (without duplicates) from page q
		LinkedHashMap<String,Integer> outLinkCountMap = new LinkedHashMap<String,Integer>();
		int count = 0;
		for(String link : inLinkMap.keySet()) {
			count = 0;
			for(String inlink : inLinkMap.keySet()) {
				value = inLinkMap.get(inlink);
				if(value.contains(link))
					count++;
			}
			if(count==0) sinkNodes.add(link);
			outLinkCountMap.put(link,count);
		}

		// d is the PageRank damping/teleportation factor; 
		//use d = 0.85 as a fairly typical value
		float d = (float) 0.85;

		// initial PageRank value  
		LinkedHashMap<String,Double> pageRankValue = new LinkedHashMap<String,Double>();
		LinkedHashMap<String,Double> newPR = new LinkedHashMap<String,Double>();
		for(String link :inLinkMap.keySet()) {
			pageRankValue.put(link, ((double) 1/N));
			newPR.put(link,((double) 1/N));
			System.out.print("PR "+link+" "+pageRankValue.get(link));
		}
		

		double sumPR;
		Boolean converged = false;
		ArrayList<Double> iteration = null;

		while(!converged){ 

			double sinkPR = 0;
			for(String page : sinkNodes) {
				sinkPR += pageRankValue.get(page);
			}

			// M(p) is the set (without duplicates) of pages that link to page p
			ArrayList<String> m = new ArrayList<String>();

			for(String page : pageRankValue.keySet()) {
				newPR.put(page,((double)((double) 1-d)/N));
				newPR.put(page,(newPR.get(page)+(d*sinkPR/N)));
				m = inLinkMap.get(page);
				for(String pg : m) {
					newPR.put(page,(newPR.get(page)+(d*pageRankValue.get(pg)/outLinkCountMap.get(pg))));
				}
			}

			for(String page : pageRankValue.keySet()) {
				pageRankValue.put(page, newPR.get(page));
			}

			sumPR = 0;
			double pr = 0;
			System.out.print("\nPage Rank");
			for(String page : pageRankValue.keySet()){
				pr = pageRankValue.get(page);
				System.out.print("\n"+page+" "+pr);
				sumPR += (pr)*(Math.log(pr)/Math.log(2));
			}
			System.out.print("\nsumPR "+sumPR);
			if(iteration == null) {
				iteration = new ArrayList<Double>();
				iteration.add(Math.pow(2,(-(sumPR))));
			}
			else
				iteration.add(Math.pow(2,(-(sumPR))));
			count = 0;
			int convergence;
			if(iteration.size()>=4){
				for(int i = iteration.size()-1;i>=(iteration.size()-3);i--) {
					System.out.print("\n"+iteration.get(i)+" "+iteration.get(i-1));
					convergence = (int) (iteration.get(i) - iteration.get(i-1));
					if(convergence<=1) count++;
					System.out.print("\nc="+convergence+" count"+count);
				}
				if(count==3){
					converged = true;
				}
			}
		}

		List list = new LinkedList(pageRankValue.entrySet());

		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		LinkedHashMap sortedPR = new LinkedHashMap();
		for (Iterator i = list.iterator(); i.hasNext();) {
			Map.Entry entry = (Map.Entry) i.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		String Top50_WG3 = " ";
		Set sortedPRSet = sortedPR.entrySet();
		Iterator iterator = sortedPRSet.iterator();
		while(iterator.hasNext()) {
			Map.Entry me = (Map.Entry)iterator.next();
			Top50_WG3 += me.getKey()+" : "+me.getValue()+"\n";
		}

		System.out.print("\n"+Top50_WG3);
		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 2";
		File customDir = new File(path1,"Task 2C");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path1 += File.separator + customDir.getName();

		File textFile = new File(path1,"Top50 WG3.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		out.append(Top50_WG3);
		out.close();

		String Perplexity = " ";
		int i =0;
		for(double val : iteration) { 
			Perplexity += "Iteration "+(i++)+" : "+val+"\n";
		}
		System.out.print("\n"+Perplexity);

		File textFile1 = new File(path1,"Perplexity - WG3.txt");
		BufferedWriter out1 = new BufferedWriter(new FileWriter(textFile1));

		out1.append(Perplexity);
		out1.close();
	}
}
