package Task_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class PageRank_WG1 {

	static LinkedHashMap<String,ArrayList> inLinkMap = new LinkedHashMap<String,ArrayList>();
	static String urlPrefix = "https://en.wikipedia.org/wiki/";
	static Set<String> pagesVisited = new HashSet<String>();
	static List<String> frontierUrlList = new LinkedList<String>();
	static Set<String> frontierUrlLookupSet = new HashSet<String>();
	static int fileCount = 1;


	@SuppressWarnings({ "null", "unchecked", "rawtypes" })
	public static void main(String[] args) throws Exception {

		LinkedHashMap<String,Integer> inLinkCountMap = new LinkedHashMap<String,Integer>();

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 2";
		path += File.separator + "Task 1A";
		path += File.separator + "Task_1A-WG1.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);

		String inData = " ";
		String [] valueList;
		String key;

		while (( inData = in.readLine()) != null) {
			valueList = inData.split(" ");
			key = valueList[0];
			inLinkCountMap.put(valueList[0],(valueList.length-2));
			inLinkMap.put(key,new ArrayList<String>());
			for(int i = 1;i<valueList.length;i++) {
				if(!inLinkMap.get(key).contains(valueList[i]))
					inLinkMap.get(key).add(valueList[i]);
			}
		}


		String inLinkGraph = "";
		//		System.out.print("Directed Web Graph\n");
		for (String item : inLinkMap.keySet()) {
			//System.out.print(item+" ");
			inLinkGraph += item+" "+inLinkMap.get(item).size()+"\n";
		}
		System.out.print(inLinkGraph);

		// P is the set of all pages; |P| = N
		int N = inLinkMap.size();

		// S is the set of sink nodes, i.e., pages that have no out links
		Set<String> sinkNodes = new HashSet<String>();
		ArrayList<String> value;

		// L(q) is the number of out-links (without duplicates) from page q
		LinkedHashMap<String,Integer> outLinkCountMap = new LinkedHashMap<String,Integer>();
		int count = 0;
		for(String link : inLinkMap.keySet()) {
			count = 0;
			for(String inlink : inLinkMap.keySet()) {
				value = inLinkMap.get(inlink);
				if(value.contains(link))
					count++;
			}
			if(count==0) sinkNodes.add(link);
			outLinkCountMap.put(link,count);
		}

		// d is the PageRank damping/teleportation factor; 
		//use d = 0.85 as a fairly typical value
		double d = (double) 0.85;

		// initial PageRank value  
		LinkedHashMap<String,Double> pageRankValue = new LinkedHashMap<String,Double>();
		LinkedHashMap<String,Double> newPR = new LinkedHashMap<String,Double>();
		for(String link :inLinkMap.keySet()) {
			pageRankValue.put(link, ((double) 1/N));
			newPR.put(link,((double)1/N));
		}

		double sumPR;
		Boolean converged = false;
		ArrayList<Double> iteration = null;

		while(!converged){ 

			double sinkPR = 0;
			for(String page : sinkNodes) {
				sinkPR += pageRankValue.get(page);
			}

			// M(p) is the set (without duplicates) of pages that link to page p
			ArrayList<String> m = new ArrayList<String>();

			for(String page : pageRankValue.keySet()) {
				newPR.put(page,((double)((double) 1-d)/N));
				newPR.put(page,(((double)newPR.get(page))+((double)((double)d*sinkPR)/N)));
				m = inLinkMap.get(page);
				for(String pg : m) {
					newPR.put(page,(((double)newPR.get(page))+((double)((double)d*pageRankValue.get(pg))/outLinkCountMap.get(pg))));
				}
			}

			for(String page : pageRankValue.keySet()) {
				pageRankValue.put(page, newPR.get(page));
			}

			sumPR = 0.0;
			double pr = 0.0;
			//System.out.print("\nPage Rank");
			for(String page : pageRankValue.keySet()){
				pr = pageRankValue.get(page);
				//System.out.print("\n"+page+" "+pr);
				sumPR += ((double)(pr)*(Math.log(pr)/Math.log(2)));
			}

			if(iteration == null) {
				iteration = new ArrayList<Double>();
				iteration.add((double)Math.pow(2,(-(sumPR))));
			}
			else
				iteration.add((double)Math.pow(2,(-(sumPR))));

			count = 0;
			double convergence;
			if(iteration.size()>4){
				for(int i = iteration.size()-1;i>=(iteration.size()-4);i--) {
					convergence = (double) (iteration.get(i) - iteration.get(i-1));
					if(Math.abs(convergence)<=1) count++;
				}
				if(count==4){
					converged = true;
				}
			}
		}

		System.out.print("\niteration converged at "+iteration.size());

		double totalPR = 0;
		for(String pg : pageRankValue.keySet())
		{
			totalPR+=pageRankValue.get(pg);
		}

		System.out.print("totalPR "+totalPR);

		List list = new LinkedList(pageRankValue.entrySet());

		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		LinkedHashMap sortedPR = new LinkedHashMap();
		for (Iterator i = list.iterator(); i.hasNext();) {
			Map.Entry entry = (Map.Entry) i.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		Set sortedPRSet = sortedPR.entrySet();
		Iterator iterator = sortedPRSet.iterator();
		int c = 0;
		String Top50_WG1 = " ";
		while(iterator.hasNext() && c<=50) {
			c++;
			Map.Entry me = (Map.Entry)iterator.next();
			Top50_WG1 += me.getKey() + " : "+me.getValue()+"\n";
		}

		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 2";
		File customDir = new File(path1,"Task 2B");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path1 += File.separator + customDir.getName();

		File textFile = new File(path1,"Top50 WG1.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		out.append(Top50_WG1);
		out.close();

		String Perplexity = " ";
		int i =0;
		for(double val : iteration) { 
			Perplexity += "Iteration "+(i++)+" : "+val+"\n";
		}

		File textFile1 = new File(path1,"Perplexity - WG1.txt");
		BufferedWriter out1 = new BufferedWriter(new FileWriter(textFile1));

		out1.append(Perplexity);
		out1.close();

		//////////////////////// changed d = 0.95		
		d = (double) 0.95;

		// initial PageRank value  
		pageRankValue.clear();
		newPR.clear();
		for(String link :inLinkMap.keySet()) {
			pageRankValue.put(link, ((double) 1/N));
			newPR.put(link,((double)1/N));
		}

		sumPR = 0;
		converged = false;
		iteration = null;

		while(!converged){ 

			double sinkPR = 0;
			for(String page : sinkNodes) {
				sinkPR += pageRankValue.get(page);
			}

			// M(p) is the set (without duplicates) of pages that link to page p
			ArrayList<String> m = new ArrayList<String>();

			for(String page : pageRankValue.keySet()) {
				newPR.put(page,((double)((double) 1-d)/N));
				newPR.put(page,(((double)newPR.get(page))+((double)((double)d*sinkPR)/N)));
				m = inLinkMap.get(page);
				for(String pg : m) {
					newPR.put(page,(((double)newPR.get(page))+((double)((double)d*pageRankValue.get(pg))/outLinkCountMap.get(pg))));
				}
			}

			for(String page : pageRankValue.keySet()) {
				pageRankValue.put(page, newPR.get(page));
			}

			sumPR = 0.0;
			double pr = 0.0;
			//System.out.print("\nPage Rank");
			for(String page : pageRankValue.keySet()){
				pr = pageRankValue.get(page);
				//System.out.print("\n"+page+" "+pr);
				sumPR += ((double)(pr)*(Math.log(pr)/Math.log(2)));
			}

			if(iteration == null) {
				iteration = new ArrayList<Double>();
				iteration.add((double)Math.pow(2,(-(sumPR))));
			}
			else
				iteration.add((double)Math.pow(2,(-(sumPR))));

			count = 0;
			double convergence;
			if(iteration.size()>4){
				for(int i1 = iteration.size()-1;i1>=(iteration.size()-4);i1--) {
					convergence = (double) (iteration.get(i1) - iteration.get(i1-1));
					if(Math.abs(convergence)<=1) count++;
				}
				if(count==4){
					converged = true;
				}
			}
		}

		System.out.print("\niteration converged at "+iteration.size());

		totalPR = 0;
		for(String pg : pageRankValue.keySet())
		{
			totalPR+=pageRankValue.get(pg);
		}

		System.out.print("totalPR "+totalPR);

		list = new LinkedList(pageRankValue.entrySet());

		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		sortedPR = new LinkedHashMap();
		for (Iterator i1 = list.iterator(); i1.hasNext();) {
			Map.Entry entry = (Map.Entry) i1.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		sortedPRSet = sortedPR.entrySet();
		iterator = sortedPRSet.iterator();
		c = 0;
		String Top50_WG1_095 = " ";
		while(iterator.hasNext() && c<=50) {
			c++;
			Map.Entry me = (Map.Entry)iterator.next();
			Top50_WG1 += me.getKey() + " : "+me.getValue()+"\n";
		}


		textFile = new File(path1,"Top50 WG1_d_095.txt");
		out = new BufferedWriter(new FileWriter(textFile));

		out.append(Top50_WG1_095);
		out.close();


		System.out.print("\n"+Perplexity+"\n"+Top50_WG1);

		list = new LinkedList(inLinkCountMap.entrySet());

		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});

		Collections.reverse(list);

		sortedPR = new LinkedHashMap();
		for (Iterator n = list.iterator(); n.hasNext();) {
			Map.Entry entry = (Map.Entry) n.next();
			sortedPR.put(entry.getKey(), entry.getValue());
		} 

		sortedPRSet = sortedPR.entrySet();
		iterator = sortedPRSet.iterator();
		c = 0;
		String inLinkCount = " ";
		while(iterator.hasNext() && c<50) {
			c++;
			Map.Entry me = (Map.Entry)iterator.next();
			inLinkCount += me.getKey() + " : "+me.getValue()+"\n";
		}

		textFile = new File(path1,"WG1-inlinkCount.txt");
		out = new BufferedWriter(new FileWriter(textFile));

		out.append(inLinkCount);
		out.close();



	}
}
