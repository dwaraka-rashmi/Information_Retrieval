package Task_1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;



import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Task1A_WG1 {

	static String urlPrefix = "https://en.wikipedia.org/wiki/";
	static Set<String> pagesVisited = new HashSet<String>();
	static List<String> frontierUrlList = new LinkedList<String>();
	static Set<String> frontierUrlLookupSet = new HashSet<String>();
	static LinkedHashMap<String,ArrayList> inLinkMap = new LinkedHashMap<String,ArrayList>();
	static int fileCount = 1;

	public static Document fetchWebPage(String url) {
		Document doc = null;
		try {
			doc = Jsoup.connect(url).header("Accept-Encoding", "gzip, deflate").maxBodySize(0).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return doc;
	}

	public static String nextUrl() {
		String nextUrl;
		do {
			nextUrl = frontierUrlList.remove(0); 
		} while((pagesVisited.contains(nextUrl)));
		pagesVisited.add(nextUrl);
		return nextUrl;
	}

	public static void getFrontierUrlList(String url) throws IOException {

		String frontierUrl; 
		Document doc = null;
		doc= fetchWebPage(url);

		Elements links = doc.select("a[href]");

		for (Element link : links) {
			if((link.attr("abs:href").startsWith(urlPrefix))&& !(link.attr("abs:href").equals("https://en.wikipedia.org/wiki/Main_Page"))) {   
				frontierUrl = (link.attr("abs:href").replace(urlPrefix," "));
				if(!(frontierUrl.contains(":"))) {  
					frontierUrl = (frontierUrl.split("#"))[0];
					frontierUrl = urlPrefix +frontierUrl.trim();
					if (frontierUrlLookupSet.add(frontierUrl)) {
						if(!pagesVisited.contains(frontierUrl)) {
							frontierUrlList.add(frontierUrl);
						}
					}
				}	
			}
		}
	}

	public static void main(String[] args) throws Exception {

		int MAX_PAGES_TO_SEARCH = 1000;
		int depth = 1;
		String seed = "https://en.wikipedia.org/wiki/Sustainable_energy";

		getFrontierUrlList(seed);
		pagesVisited.add(seed);
		depth++;
		int depthSize = frontierUrlList.size();

		while( (depth <=5) && (pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
			while((depthSize > 0) && (pagesVisited.size() < MAX_PAGES_TO_SEARCH)){
//				TimeUnit.SECONDS.sleep(1);//delay for politeness policy
				getFrontierUrlList(nextUrl());
				depthSize--;
			}
			depth++;
			depthSize = frontierUrlList.size();
		}

		for(String item : pagesVisited) {

//			TimeUnit.SECONDS.sleep(1);//delay for politeness policy
			String frontierUrl; 
			Document doc = null;
			doc= fetchWebPage(item);
			Elements links = doc.select("a[href]");

			for (Element link : links) {
				if((link.attr("abs:href").startsWith(urlPrefix))) {   
					frontierUrl = (link.attr("abs:href").replace(urlPrefix," "));
					if(!(frontierUrl.contains(":"))) {  
						frontierUrl = (frontierUrl.split("#"))[0];
						frontierUrl = urlPrefix +frontierUrl.trim();
						if(pagesVisited.contains(frontierUrl)){
							if(!inLinkMap.containsKey(frontierUrl)) {
								inLinkMap.put(frontierUrl,new ArrayList<String>());
								if(!inLinkMap.get(frontierUrl).contains(item))
									inLinkMap.get(frontierUrl).add(item);
							}
							else if(!inLinkMap.get(frontierUrl).contains(item))
								inLinkMap.get(frontierUrl).add(item);
						}	
					}
				}
			}
		}

		String WG1 = "";
		String docId = " ";
		for (String item : inLinkMap.keySet()) {
			docId = (item.replace(urlPrefix," ")).trim();
			WG1 += docId;
			ArrayList<String> inlinks =  inLinkMap.get(item);
			for(String link : inlinks) {
				docId = (link.replace(urlPrefix," ")).trim();
				WG1 += " " +docId;
			}
			WG1 +="\n";
		}


		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 2";

		File customDir = new File(path,"Task 1A");
		if (!customDir.exists()) {
			customDir.mkdirs(); 
		}
		path += File.separator + customDir.getName();

		File textFile = new File(path, "Task_1A-WG1.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		out.append(WG1);
		out.close();


	}
}
