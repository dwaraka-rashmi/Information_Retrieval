package Task_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;


public class Task1B_WG2 {

	static LinkedHashMap<String,ArrayList> inLinkMap = new LinkedHashMap<String,ArrayList>();

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 2";
		path += File.separator + "Task 1B";
	    path += File.separator + "Task_1B-WG2.txt";

		FileReader file = new FileReader(path);
		BufferedReader in = new BufferedReader(file);

		String inData = " ";
		String [] valueList;
		String key;

		while (( inData = in.readLine()) != null) {
			valueList = inData.split(" ");
			key = valueList[0];
			if(!inLinkMap.containsKey(valueList[0])) {
				inLinkMap.put(key,new ArrayList<String>());
				for(String val : valueList) {
					if(!val.matches(key))
						if(!inLinkMap.get(key).contains(val))
							inLinkMap.get(key).add(val);
				}
			}
		}
		
		System.out.print("inlinkGraph formed\n");
//		Set<String> sinkNodes = new HashSet<String>();
//		ArrayList<String> value;

		// L(q) is the number of out-links (without duplicates) from page q
//		LinkedHashMap<String,Integer> outLinkCountMap = new LinkedHashMap<String,Integer>();
//		int count = 0;
//		for(String link : inLinkMap.keySet()) {
//			count = 0;
//			for(String inlink : inLinkMap.keySet()) {
//				value = inLinkMap.get(inlink);
//				if(value.contains(link))
//					count++;
//			}
//			if(count==0) sinkNodes.add(link);
//			outLinkCountMap.put(link,count);
//		}
		
//		for (String item : inLinkMap.keySet()) {
//			System.out.print(item);
//			ArrayList<String> inlinks =  inLinkMap.get(item);
//			for(String link : inlinks) {
//				System.out.print(" "+link);
//			}
//			System.out.print("\n");
//		}
		
		String inLinkGraph = "";
		for(Entry e : inLinkMap.entrySet())
		{
		   inLinkGraph += e.getKey()+" "+inLinkMap.get(e.getKey()).size()+"\n";	
		}
//		System.out.print(inLinkGraph);
	
		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 2";
		File textFile = new File(path1,"WG2-outlinkCount.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(textFile));

		out.append(inLinkGraph);
		out.close();

		

	}
	
}
