To upload the WG2 graph, place the file Task_1B-WG2.txt in the below path
C:\Users\<User-Name>\Documents\IR Assignment 2\Task 1B

