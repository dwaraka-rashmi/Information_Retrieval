
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;


public class extractFeatures2 {

	public static Set<String> uniqueterms = new HashSet<String>();
	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static LinkedHashMap<Integer,String> termIndex =	new LinkedHashMap<Integer,String>();

	public static void readTermIndex() throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 4"+ File.separator;


		FileReader file = new FileReader(path+"indexTC_trial.out");
		BufferedReader in = new BufferedReader(file);
		String inData = " ";
		String [] valueList;

		while (( inData = in.readLine()) != null) {
			valueList = inData.split("->");
			termIndex.put(Integer.parseInt(valueList[0]), valueList[1]);
			vocabulary.add(valueList[1]);
		}

		System.out.println("termIndex built. Index size "+termIndex.size());

	}

	public static void readTrainDataCollection() throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 4";
		path += File.separator + "textcat";
		path += File.separator + "train";

		String posPath = path + File.separator + "pos";
		String negPath = path + File.separator + "neg";
		String train_data = "";

		final File posfiles = new File(posPath);

		for (File fileEntry : posfiles.listFiles()) {

			String each_file = "";

			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
			each_file += "+1 ";
			LinkedList<String> terms = new LinkedList<String>();
			while (( inData = in.readLine()) != null) {
				valueList = inData.split(" ");
				for(String term : valueList) {
					terms.add(term);
				}
			}

//			Double docLength = (double)terms.size();
			Double maxTf = 0.0;
			LinkedList<Double> tf = new LinkedList<Double>();
			for(String term : terms){
				tf.add((double)Collections.frequency(terms, term));
			}
			Collections.sort(tf);
			
//			System.out.println("first"+tf.getFirst());
//			System.out.println("last"+tf.getLast());
			maxTf = tf.getLast();
			
			for(Entry<Integer, String> e : termIndex.entrySet()) {
				if(terms.contains(e.getValue()))
					each_file += e.getKey()+":"+((double)((double)Collections.frequency(terms, e.getValue())/maxTf))+" ";
			}

			train_data += each_file+"\n";
			in.close();
			//System.out.println(fileEntry.getName());

		}

		System.out.print("\n Positive train data created");

		final File negfiles = new File(negPath);

		for (File fileEntry : negfiles.listFiles()) {

			String each_file = "";
			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
			each_file += "-1 ";
			LinkedList<String> terms = new LinkedList<String>();
			while (( inData = in.readLine()) != null) {
				valueList = inData.split(" ");
				for(String term : valueList) {
					terms.add(term);
				}
			}

//			Double docLength = (double)terms.size();
			Double maxTf = 0.0;
			LinkedList<Double> tf = new LinkedList<Double>();
			for(String term : terms){
				tf.add((double)Collections.frequency(terms, term));
			}
			Collections.sort(tf);
			
//			System.out.println("first"+tf.getFirst());
//			System.out.println("last"+tf.getLast());
			maxTf = tf.getLast();

			for(Entry<Integer, String> e : termIndex.entrySet()) {
				if(terms.contains(e.getValue()))
					each_file += e.getKey()+":"+((double)((double)Collections.frequency(terms, e.getValue())/maxTf))+" ";
			}

			train_data += each_file+"\n";
			in.close();
			//System.out.println(fileEntry.getName());

		}

		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 4";

		File trainIndexData = new File(path1,"train_data_enhanced_trial.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(trainIndexData));

		out.append(train_data);
		out.close();

		System.out.print("\n train data created");


	}

	public static void readTestDataCollection() throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 4";
		path += File.separator + "textcat";
		path += File.separator + "dev";

		String posPath = path + File.separator + "pos";
		String negPath = path + File.separator + "neg";
		String test_data = "";

		final File posfiles = new File(posPath);

		for (File fileEntry : posfiles.listFiles()) {

			String each_file = "";

			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
			each_file += "+1 ";
			LinkedList<String> terms = new LinkedList<String>();
			while (( inData = in.readLine()) != null) {
				valueList = inData.split(" ");
				for(String term : valueList) {
					terms.add(term);
				}
			}

//			Double docLength = (double)terms.size();
			Double maxTf = 0.0;
			LinkedList<Double> tf = new LinkedList<Double>();
			for(String term : terms){
				tf.add((double)Collections.frequency(terms, term));
			}
			Collections.sort(tf);
			
//			System.out.println("first"+tf.getFirst());
//			System.out.println("last"+tf.getLast());
			maxTf = tf.getLast();

			for(Entry<Integer, String> e : termIndex.entrySet()) {
				if(terms.contains(e.getValue()))
					each_file += e.getKey()+":"+((double)((double)Collections.frequency(terms, e.getValue())/maxTf))+" ";
			}

			test_data += each_file+"\n";
			in.close();
			//System.out.println(fileEntry.getName());

		}
		System.out.print("\n Positive train data created");

		final File negfiles = new File(negPath);

		for (File fileEntry : negfiles.listFiles()) {

			String each_file = "";
			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
			each_file += "-1 ";
			LinkedList<String> terms = new LinkedList<String>();
			while (( inData = in.readLine()) != null) {
				valueList = inData.split(" ");
				for(String term : valueList) {
					terms.add(term);
				}
			}

//			Double docLength = (double)terms.size();
			Double maxTf = 0.0;
			LinkedList<Double> tf = new LinkedList<Double>();
			for(String term : terms){
				tf.add((double)Collections.frequency(terms, term));
			}
			Collections.sort(tf);
			
//			System.out.println("first"+tf.getFirst());
//			System.out.println("last"+tf.getLast());
			maxTf = tf.getLast();

			for(Entry<Integer, String> e : termIndex.entrySet()) {
				if(terms.contains(e.getValue())) 
					each_file += e.getKey()+":"+((double)((double)Collections.frequency(terms, e.getValue())/maxTf))+" ";
			}

			test_data += each_file+"\n";
			in.close();
			//System.out.println(fileEntry.getName());

		}

		String path1 = System.getProperty("user.home") + File.separator + "Documents";
		path1 += File.separator + "IR Assignment 4";

		File trainIndexData = new File(path1,"test_data_enhanced_trial.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(trainIndexData));

		out.append(test_data);
		out.close();

		System.out.print("\n test data created");



	}

	public static void main(String[] args) throws IOException {

		readTermIndex();
		readTrainDataCollection();
		readTestDataCollection();

	}


}
