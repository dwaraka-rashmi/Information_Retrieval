import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;


public class processDataIndex {
	
	public static Set<String> uniqueterms = new HashSet<String>();
	public static LinkedList<String> terms = new LinkedList<String>();
	public static LinkedList<String> vocabulary = new LinkedList<String>();
	public static LinkedHashMap<Integer,String> termIndex =	new LinkedHashMap<Integer,String>();
	public static LinkedHashMap<String,Integer> termIndexFreq =	new LinkedHashMap<String,Integer>();
	
	public static String strip(String data) {
		
		while(data.endsWith(" ")){
			data = data.substring(0,data.length()-1);
		}
		while(data.startsWith(" ")){
			data = data.substring(1);
		}
		return data;
		
	}
	
	public static void readDataCollection() throws IOException {

		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 4";
		path += File.separator + "textcat";
		path += File.separator + "data";
		
		final File files = new File(path);

		for (File fileEntry : files.listFiles()) {

			FileReader file = new FileReader(fileEntry);
			BufferedReader in = new BufferedReader(file);
			String inData = " ";
			String [] valueList;
		
			while (( inData = in.readLine()) != null) {
                inData= strip(inData);
				valueList = inData.split("[\\s\\t\\n]");
				for(String term : valueList) {
					//term = term.replaceAll(" ", "");
					if(termIndexFreq.keySet().contains(term))
						termIndexFreq.put(term,(termIndexFreq.get(term)+1));
					else
						termIndexFreq.put(term,1);
				}
			}
				
			in.close();
			System.out.println(fileEntry.getName());

		}

		System.out.println("Read all files");
		String Result = "";
		int i = 1;
		for(Entry<String, Integer> e : termIndexFreq.entrySet()) {
			if(e.getValue()>=5)
			vocabulary.add(e.getKey());
		}
		
		Collections.sort(vocabulary);

		System.out.print("\n vocabulary size "+vocabulary.size());

	}


	public static void main(String[] args) throws IOException {

		readDataCollection();
		int i = 1;
		String Result = "";
		for(String term : vocabulary) {
			Result += i+"->"+term+"\n";
			termIndex.put(i++, term);
			
		}
		
		String path = System.getProperty("user.home") + File.separator + "Documents";
		path += File.separator + "IR Assignment 4";

		File termIndexData = new File(path,"indexTC.out");
		BufferedWriter out = new BufferedWriter(new FileWriter(termIndexData));

		out.append(Result);
		out.close();
		
		System.out.println("vocabulary created");
		System.out.print("\n vocabulary size "+vocabulary.size());

    }


}
